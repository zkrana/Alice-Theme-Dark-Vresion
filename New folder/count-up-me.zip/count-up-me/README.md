# countMe
A jQuery plugin for count numbers
https://qasim345.github.io/countMe
Useg:
```html
<!-- add jquery and countMe script files -->
<script src="res/jquery.min.js"></script>
<script src="res/countMe/countMe.min.js"></script>
```
Codes:
```html
<script type="text/javascript">
   // $(selector).countMe(delay,speed)
   $("#num1").countMe(300,30);
   $("#status-count").countMe(50,80);
</script>
```
