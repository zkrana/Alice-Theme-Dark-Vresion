# mkinfinite
jquery.mkinfinite.js — jQuery plugin for infinite background zoom animation
